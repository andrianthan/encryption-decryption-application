This is a demo archive for encryption testing.
It contains multiple files of different types.