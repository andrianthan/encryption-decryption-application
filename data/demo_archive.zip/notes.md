# Demo Notes

## Purpose
This archive demonstrates that ZIP files can be encrypted.

## Contents
- Configuration files
- Data files
- Documentation
